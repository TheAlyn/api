

<?php $__env->startSection('title', 'Listagem de Tarefas'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Listagem</h1>

    <a href="">Adicionar Nova Tarefa</a>

    <?php if(count($list) > 0): ?>
    <ul>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="">[ <?php if($item->RESOLVIDO===1): ?>
                    desmarcar
                <?php else: ?> 
                    marcar
                <?php endif; ?> ]</a>
                <?php echo e($item->TITULO); ?>

                <a href="">[ editar ]</a>
                <a href="">[ excluir ]</a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php else: ?>
        Não há tarefas a serem listadas.
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alyss\Desktop\Projetos\IERNT\ierntapi\resources\views/tarefas/list.blade.php ENDPATH**/ ?>