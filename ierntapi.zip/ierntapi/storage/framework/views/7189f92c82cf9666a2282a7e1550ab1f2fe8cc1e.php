<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?> - IERNT</title>
    </head>
    <body>
        <header>
            <h1>Header</h1>
        </header>
        <hr/>
        <section>
            <?php echo $__env->yieldContent('content'); ?>
        </section>
        <hr/>
        <footer>
            Sistema desenvolvido por IERNT
        </footer>
    </body>
</html><?php /**PATH C:\Users\alyss\Desktop\Projetos\IERNT\ierntapi\resources\views/layouts/admin.blade.php ENDPATH**/ ?>