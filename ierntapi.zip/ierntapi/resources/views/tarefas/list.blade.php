@extends('layouts.admin')

@section('title', 'Listagem de Tarefas')

@section('content')
    <h1>Listagem</h1>

    <a href="">Adicionar Nova Tarefa</a>

    @if(count($list) > 0)
    <ul>
        @foreach ($list as $item)
            <li>
                <a href="">[ @if ($item->RESOLVIDO===1)
                    desmarcar
                @else 
                    marcar
                @endif ]</a>
                {{$item->TITULO}}
                <a href="">[ editar ]</a>
                <a href="">[ excluir ]</a>
            </li>
        @endforeach
    </ul>
    @else
        Não há tarefas a serem listadas.
    @endif

@endsection