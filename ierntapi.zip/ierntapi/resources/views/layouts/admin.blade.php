<!DOCTYPE html>
<html>
    <head>
        <title>@yield('title') - IERNT</title>
    </head>
    <body>
        <header>
            <h1>Header</h1>
        </header>
        <hr/>
        <section>
            @yield('content')
        </section>
        <hr/>
        <footer>
            Sistema desenvolvido por IERNT
        </footer>
    </body>
</html>